package com.example.reports_vendify

import android.content.Context
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

class ReportGenerator {
    fun generatePdf(context: Context, data: List<Map<String, Any>>): String {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(300, 600, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = android.graphics.Paint().apply { textSize = 12f }

        var y = 25
        for (item in data) {
            val label = item["label"].toString()
            val value = item["value"].toString()
            canvas.drawText("$label: $value", 10f, y.toFloat(), paint)
            y += 20
        }

        document.finishPage(page)

        val file = File(context.filesDir, "reporte_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file.absolutePath
    }
}

