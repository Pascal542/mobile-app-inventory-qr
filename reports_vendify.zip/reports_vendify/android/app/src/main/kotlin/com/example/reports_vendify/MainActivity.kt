package com.example.reports_vendify

import android.os.Bundle
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "vendify.com/reports"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "generateReport") {
                @Suppress("UNCHECKED_CAST")
                val data = call.argument<List<Map<String, Any>>>("data") ?: emptyList()
                val filePath = ReportGenerator().generatePdf(this, data)
                result.success(filePath)
            } else {
                result.notImplemented()
            }
        }
    }
}

