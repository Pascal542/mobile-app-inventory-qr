import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ReportesVendify extends StatelessWidget {
  final MethodChannel _channel = const MethodChannel('vendify.com/reports');

  ReportesVendify({super.key});

  Future<void> _generatePdfReport() async {
    try {
      final data = [
        {'label': 'Nombre', 'value': 'Juan Pérez'},
        {'label': 'Edad', 'value': '30'},
        {'label': 'Ciudad', 'value': 'Lima'},
      ];

      final path = await _channel.invokeMethod('generateReport', {'data': data});
      print('PDF generado en: $path');
    } on PlatformException catch (e) {
      print('Error al generar PDF: ${e.message}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Generar Reporte'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: _generatePdfReport,
          child: const Text('Generar Reporte en PDF'),
        ),
      ),
    );
  }
}
